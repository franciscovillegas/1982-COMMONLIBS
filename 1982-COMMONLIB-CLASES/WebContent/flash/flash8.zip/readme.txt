Archived Flash Player versions available for testing 

The files you have downloaded here are specifically for Macromedia Flash developers who are testing their movies with older Flash Players. For normal use, please download the current version of the Flash Player, available from the Flash Player Download Center (http://www.adobe.com/go/getflash).

ADobe has made these archived players available for download at the request of the Flash developer community. Macromedia Technical Support does not provide support for the installation or use of these old players.

Before installing a different Flash Player we recommend uninstalling the currently installed Flash Player and restarting the system. For more information on removing and installing the Flash Player, see How to uninstall the Flash plug-in and ActiveX Control (TechNote 14157, http://www.adobe.com/cfusion/knowledgebase/index.cfm?id=tn_14157).

Except as expressly provided otherwise in an agreement between you and Adobe, all players are provided "AS IS" without warranty of any kind, for testing purposes only. 

Your use of these players is governed by the End User License Agreement found at http://www.adobe.com/shockwave/download/license/desktop/. Distribution of these players is prohibited except as expressly provided otherwise in an agreement between you and Adobe.

In no event will Adobe be liable for any special, indirect or consequential damages or any damages whatsoever resulting from the loss of use, data or profits, whether in an action for breach of contract or warranty or tort (including negligence) arising out of or in connection with the information or software.

Adobe may make changes to the information, software, technical specification and at any time and without notice.


The following files are available for your use:

Flash Player 8,0,24,0
---------------------
Windows 9x/ME/NT/2000/XP
- Internet Explorer: flashplayer8r24_winax.exe
- Netscape: flashplayer8r24_win.exe
Mac OS PowerPC
- flashplayer8r24_mac.dmg